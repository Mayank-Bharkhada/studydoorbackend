const express = require('express');
const InstituteModel = require('../schema/InstituteSchema');
const bcrypt = require('bcrypt');
const router = express.Router();
const mongoose = require('mongoose');
const path = require('path');
const multer = require('multer');

//call through /api/User/Institute_login

router.post("/Institute_login",async (req,res) => {
  try {
    const yourEmail = req.body.Email;
    const yourPassword = req.body.Password; 
    const doc = await InstituteModel.findOne({ email: yourEmail });
    if (!doc) {
      return res.status(404).send('No user found');
    } else {
      // console.log(doc);
      const hashedPassword = doc.password;
    
      if(yourEmail == doc.email){
       bcrypt.compare(yourPassword, hashedPassword, (err, result) => {
         if (result) {
           console.log(result);
           res.json([{
             id : 1,
             text : "We welcome your institute."
           }]);
         } else if (err) {
           console.log(err);
           res.json([{
               id : 0,
               text : "Enter valid details"
             }]);
         } else {
           res.json([{
             id : 0,
             text : "Enter valid details"
           }]);
         }
        } );
          
         }else{
          res.json([{
              id : 0,
              text : "Enter valid details"
            }]);
        }
      
    }
 
       } catch (error) {
        console.log(error);
        res.status(500).send(error);
      }
});


//call through /api/User/Institute_registration

router.post("/Institute_registration",async (req,res) => {
    try {
      console.log(req.body);
      const yourName = req.body.Name;
      const yourEmail= req.body.Email;
      const yourPhone = req.body.Phone;
      const yourAddress = req.body.Address;
      const yourDateOfEstablishment = req.body.DateOfEstablishment;
      const saltRounds = 10;
      const yourPassword = req.body.Password; 
      const yourCity = req.body.City; 
      const yourState = req.body.State; 
      const yourCountry = req.body.Country; 
      const yourPincode = req.body.Pincode; 
      
      const salt = await bcrypt.genSalt(saltRounds);
      const Password = await bcrypt.hash(yourPassword, salt);
        const Institute = new InstituteModel ({
          name: yourName,
          email: yourEmail,
          phone: yourPhone,
          dateOfEstablishment: yourDateOfEstablishment,
          password: Password ,
          address: yourAddress,
          city: yourCity ,
          state: yourState ,
          country: yourCountry ,
          pincode: yourPincode ,
        });
          await Institute.save();
    
          res.json([{
            id : 1,
            text : "Data is Success fully inserted"
          }]);
          
        } catch (error) {
          console.log(error);
          res.status(500).send(error);
        }
  });
  


//call through /api/User/All_institutes_data

router.get('/All_institutes_data', (req, res) => {
    InstituteModel.find((err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching data' });
        }
        return res.status(200).json(data);
    });
});


  //call through /api/User/institute/Varification_request

  const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      if (file.fieldname === "InstituteCertificate") { 
        cb(null, './Uploads/Photos/Institute_varification_photos/InstituteCertificates');
      } else if (file.fieldname === "VarificationPhoto") {
        cb(null, './Uploads/Photos/Institute_varification_photos/VarificationPhotos');
      } else {
        console.log("There is no photo.")
      }
    },
    filename: async function  (req, file, cb) {
      console.log("------------------------------");
      console.log(req.body);
    console.log("------------------------------");
      if (file.fieldname === "InstituteCertificate") { // if uploading resume
      const File_name = file.fieldname + '-' + Date.now() + path.extname(file.originalname);
      cb(null, File_name);
      InstituteModel.updateOne({ email: req.body.Email }, { instituteCertificate : File_name }, (error, result) => {
        if (error) {
          console.error(error);
        } else {
          console.log(result);
        }
      });
    } else if (file.fieldname === "VarificationPhoto") {
      const File_name = file.fieldname + '-' + Date.now() + path.extname(file.originalname);
      cb(null, File_name);
      InstituteModel.updateOne({ email: req.body.Email }, { varificationPhoto : File_name }, (error, result) => {
        if (error) {
          console.error(error);
        } else {
          console.log(result);
        }
      });
    } else {
      console.log("There is no photo.")
    }

    }
  });
  
  const upload = multer({ storage: storage });
  router.post("/institute/Varification_request",  upload.fields([
    { name: 'InstituteCertificate', maxCount: 1 },
    { name: 'VarificationPhoto', maxCount: 1 },
  ]),async (req,res) => {
    const yourEmail= req.body.Email;
        res.json([{
          id : 1,
          text : "Data is Success fully inserted"
        }]);
  
  });

module.exports = router;